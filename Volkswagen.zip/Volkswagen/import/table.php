<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<table class="table>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<body>
<br>
<table class="table container">
  <thead>
    <tr>
      <th scope="col">Identificação do Carro</th>
      <th scope="col">Modelo</th>
      <th scope="col">Cor</th>
      <th scope="col">Preço</th>
      <th scope="col">Ano</th>
      <th scope="col">Editar</th>
      <th scope="col">Apagar</th>
    </tr>
  </thead>



</body>
</html>