<?php
include('carroModel.php');
$carroModel = new Carro();

$id = isset($_GET['id_carro']) ? $_GET['id_carro'] : '';
if (!empty($id)) {
  $carro = $carroModel->getById($id);
  if (count($carro) > 0) {
    $result = $carro;
  }
}
$modelo_carro = isset($result) ? $result['modelo_carro'] : '';
$cor_carro = isset($result) ? $result['cor_carro'] : '';
$valor = isset($result) ? $result['valor'] : '';
$ano = isset($result) ? $result['ano'] : '';
$action = isset($_POST['action']) ? $_POST['action'] : '';

if ($action == 'cadastrar') {
  $carroModel->insert($_POST['modelo_carro'], $_POST['cor_carro'], $_POST['valor'], $_POST['ano']);
} else if ($action == 'atualizar') {
  $carroModel->update($_POST['modelo_carro'], $_POST['cor_carro'], $_POST['valor'], $_POST['ano'], $_POST['idCarro']);
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Volkswagen</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="shortcut icon" href="img/volkswagenLogo.png" type="image/x-icon">
</head>

<body data-bs-theme="dark">
  <nav class="navbar bg-dark border-bottom border-body" data-bs-theme="dark"><!--Início da Navbar-->
    <div class="container-fluid">
      <a class="navbar-brand" href="home.php">Volkswagen</a>
      <img src="img/volkswagenLogo.png" alt="Logo Volkswagen" width="100px" height="100px">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="formCarro.php"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16">
                <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" />
                <path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z" />
              </svg> Cadastro</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="consult.php"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-newspaper" viewBox="0 0 16 16">
                <path d="M0 2.5A1.5 1.5 0 0 1 1.5 1h11A1.5 1.5 0 0 1 14 2.5v10.528c0 .3-.05.654-.238.972h.738a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 1 1 0v9a1.5 1.5 0 0 1-1.5 1.5H1.497A1.497 1.497 0 0 1 0 13.5v-11zM12 14c.37 0 .654-.211.853-.441.092-.106.147-.279.147-.531V2.5a.5.5 0 0 0-.5-.5h-11a.5.5 0 0 0-.5.5v11c0 .278.223.5.497.5H12z" />
                <path d="M2 3h10v2H2V3zm0 3h4v3H2V6zm0 4h4v1H2v-1zm0 2h4v1H2v-1zm5-6h2v1H7V6zm3 0h2v1h-2V6zM7 8h2v1H7V8zm3 0h2v1h-2V8zm-3 2h2v1H7v-1zm3 0h2v1h-2v-1zm-3 2h2v1H7v-1zm3 0h2v1h-2v-1z" />
              </svg> Consultar</a>
          </li>
        </ul>
      </div>
    </div>
  </nav><!-- Fim da Navbar -->

  <section class="container"><!-- Seção do Formulário-->
    <h1>Cadastro de Carros</h1>
    <form action="formCarro.php" method="POST">
      <div class="inputs-labels-insert">
        <input hidden name='action' value='<?= count($_GET) > 0 ? 'atualizar' : 'cadastrar' ?>'>
        <input hidden name='idCarro' id='idCarro' value='<?=$_GET['id_carro']?>'>
        <label for="modelo">Modelo:</label>
        <input type="text" class="form-control" required name="modelo_carro" placeholder="Fusca" value="<?= $modelo_carro ?>"><br>
        <label for="cor">Cor:</label>
        <input type="text" class="form-control" name="cor_carro" placeholder="Azul" value="<?= $cor_carro ?>"><br>
        <label for="valor">Valor:</label>
        <input type="number" class="form-control" name="valor" placeholder="10.000" value="<?= $valor ?>"><br>
        <label for="ano">Ano:</label>
        <input type="number" class="form-control" name="ano" placeholder="2010" value="<?= $ano ?>"><br>
        <input type="submit" class="btn btn-outline-secondary" value="<?= count($_GET) > 0 ? "Atualizar" : "Cadastrar" ?>">
      </div>
      <img src="img/fuscaInsert2.png" alt="oldFusca" class="imgFuscaInsert">
    </form>
  </section><!-- Fim da seção do formulário-->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>